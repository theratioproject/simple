
/* 
	Copyright (c) 2017-2018 Azeez Adewale <azeezadewale98@gmail.com"> 
	MIT License Copyright (c) 2017 simple 

*/

/* 
 * File:   simple.c
 * Author: thecarisma
 *
 * Created on July 10, 2017, 1:29 PM
 */

#include "../includes/ring.h"

int main( int argc, char *argv[])
{
	ring_state_main(argc,argv);
	return 0;
}
